next | master
------------ | -------------
[![Travis-CI Build Status](https://travis-ci.org/OCamlPro/alt-ergo.svg?branch=next)](https://travis-ci.org/OCamlPro/alt-ergo) | [![Travis-CI Build Status](https://travis-ci.org/OCamlPro/alt-ergo.svg?branch=master)](https://travis-ci.org/OCamlPro/alt-ergo) 

# Alt-Ergo

Alt-Ergo is an automatic theorem prover of mathematical formulas. It
was developed at LRI, and is now maintained at OCamlPro:

See more details on http://alt-ergo.ocamlpro.com/


## Copyright

See enclosed LICENSE.md file


## Build, Installation and Usage

See enclosed sources/INSTALL.md file


## Support

See http://alt-ergo.ocamlpro.com/support.php or contact us at
contact@ocamlpro.com for more details
