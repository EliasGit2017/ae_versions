**************************
Developer's documentation
**************************

.. toctree::
   :maxdepth: 2
   :caption: Contents
   
   Project Architecture          <architecture.md>
   Contributing guidelines       <contributing.md>

