# Project Architecture

If you're new to Alt-Ergo (or not), you may want to get the list of
modules (files) with their dependencies with the following command:

    make modules-dep-graph

If everything goes well with the command above, a file
modules-dep-graph.pdf will be generated.
