******
About
******

Additonal informations about Alt-Ergo

.. toctree::
   :maxdepth: 2
   :caption: Contents

   Licenses                   <licenses/index>
   Changes                   <changes.md>
   Try-Alt-Ergo              <https://alt-ergo.ocamlpro.com/try.html>
   Alt-Ergo's website        <https://alt-ergo.ocamlpro.com/>
   Scientific publications   <https://alt-ergo.ocamlpro.com/#publications>
