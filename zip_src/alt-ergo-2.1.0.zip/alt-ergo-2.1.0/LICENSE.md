## Copyright

These software are distributed in the hope that they will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

Please, do not use enclosed software until you have read and accepted
the terms of the licensing below. The use of these software implies
that you automatically agree with our terms and conditions. In case of
doubt, please contact us to clarify licensing.

The resources are licensed as follows:

### OCaml source files and Alt-Ergo preludes

Some of these files are Copyright (C) 2006-2013 --- CNRS - INRIA -
Universite Paris Sud, and Copyright (C) 2013-2017 --- OCamlPro SAS.
They are distributed under the terms of the Apache Software License
version 2.0.

The other files are Copyright (C) --- OCamlPro SAS. They are
distributed under the terms of the license indicated in the file
'License.OCamlPro'.

You may want to refer to the header of each file to know under which
license it is distributed.


### Binaries generated from the source files

The binaries (tools, plugins, ...) that are generated from the OCaml
source files are Copyright (C) --- OCamlPro SAS. They are distributed
under the terms of the license indicated in the file
'License.OCamlPro'.
