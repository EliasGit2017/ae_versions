
******************
Input file formats
******************

Alt-ergo supports different input language. The main language is his native language, based on the lamguage of the Why plateform and detailed below. Alt-ergo (partially) supports the standard language of the SMT community, SMT-LIB. It also (partially) supports the input language of Why3.

.. toctree::
   :maxdepth: 2
   :caption: Contents
   
   Alt-Ergo's native language <Native/index>
   SMT-LIB                    <http://smtlib.cs.uiowa.edu/papers/smt-lib-reference-v2.6-r2017-07-18.pdf>
   WhyML (partial support)    <http://why3.lri.fr/doc/syntaxref.html>
