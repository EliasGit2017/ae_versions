
# Syntax of declarations and expressions 

[TODO: intro + all]
[Full definition of the syntax in (restricted) BNF] 
